var tabIsOpenTitle = 'Popup window is already open. Click to focus popup.';
var tabIsClosedTitle = 'Open popup window';
var popupTabId = false; // popupTabId can be true, false, or the popup's tab Id.

chrome.browserAction.onClicked.addListener(function () {
    let url = 'popup.html';

    if (popupTabId === false) {
        chrome.browserAction.setTitle({ title: tabIsOpenTitle });
        chrome.tabs.create({ url: url }, function (tab) {
            popupTabId = tab.id;
        });
    } else if (typeof popupTabId === 'number') {
        chrome.tabs.update(popupTabId, { active: true }, function (tab) {
            chrome.windows.update(tab.windowId, { focused: true });
        });
    }
});

chrome.tabs.onRemoved.addListener(function (tabId) {
    if (popupTabId === tabId) {
        chrome.browserAction.setTitle({ title: tabIsClosedTitle });
        popupTabId = false;
    }
});